﻿namespace LogicTier
{
    public class Магазин
    {
        private List<ТоварнаяПозиация> _товары = new List<ТоварнаяПозиация>();

        public Магазин(List<ТоварнаяПозиация> позиции)
        {
            _товары = позиции;
        }

        public List<ТоварнаяПозиация> СписокТоваров
        {
            get { return _товары; }
        }

        // Суммарная стоимость объектов по каждому типу строения
        public string СуммарнаяСтоимостьПоТипу
        {
            get
            {
                var grouped = _товары
                    .GroupBy(p => p.ТипСтроения)
                    .Select(g => new
                    {
                        Тип = g.Key,
                        Сумма = g.Sum(p => p.СуммарнаяСтоимостьПозиции)
                    });

                return string.Join(Environment.NewLine, grouped.Select(g => $"{g.Тип}: {g.Сумма}"));
            }
        }

        // Средняя стоимость квадратного метра для всех товаров
        public string СредняяСтоимостьКвМетра
        {
            get
            {
                var стоимости = _товары
                    .Where(p => p.Метраж > 0)
                    .Select(p => p.Стоимость / p.Метраж);

                return $"Средняя стоимость кв. метра: {стоимости.Average():F2}";
            }
        }
    }
}
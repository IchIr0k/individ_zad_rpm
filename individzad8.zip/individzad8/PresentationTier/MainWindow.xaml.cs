﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Магазин магазин;
    public MainWindow()
    {
        InitializeComponent();
        
    }

    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        List<Товар> товарыИзФайла = ВсеТовары.ПолучитьВсеТоварыИзФайла();

        if (товарыИзФайла.Count == 0)
        {
            MessageBox.Show("Нет товаров в файле!");
            return;
        }

        List<ТоварнаяПозиация> позиции = new List<ТоварнаяПозиация>();
        foreach (var t in товарыИзФайла)
        {
            позиции.Add(new ТоварнаяПозиация(t));
        }

        магазин = new Магазин(позиции);
        this.DataContext = магазин;
    }

}




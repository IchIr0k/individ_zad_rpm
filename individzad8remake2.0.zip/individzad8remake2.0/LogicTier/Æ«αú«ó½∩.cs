﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace LogicTier
{
    public class Торговля : INotifyPropertyChanged
    {
        private ObservableCollection<ОбъектПозиция> _товары;

        public Торговля(ObservableCollection<ОбъектПозиция> позиции)
        {
            _товары = позиции;
            _товары.CollectionChanged += (s, e) =>
            {
                OnPropertyChanged(nameof(СуммарнаяСтоимостьПоТипу));
                OnPropertyChanged(nameof(СредняяСтоимостьКвМетра));
            };
        }

        public ObservableCollection<ОбъектПозиция> СписокТоваров
        {
            get => _товары;
        }

        public string СуммарнаяСтоимостьПоТипу
        {
            get
            {
                var grouped = _товары
                    .GroupBy(p => p.ТипСтроения)
                    .Select(g => new
                    {
                        Тип = g.Key,
                        Сумма = g.Sum(p => p.Стоимость)
                    });

                return string.Join(System.Environment.NewLine, grouped.Select(g => $"{g.Тип}: {g.Сумма}"));
            }
        }

        public string СредняяСтоимостьКвМетра
        {
            get
            {
                var объекты = _товары.Where(p => p.Метраж > 0);

                double суммарнаяСтоимость = объекты.Sum(p => p.Стоимость);
                double суммарныйМетраж = объекты.Sum(p => p.Метраж);

                return суммарныйМетраж > 0
                    ? $"{(суммарнаяСтоимость / суммарныйМетраж):F2}"
                    : "";
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

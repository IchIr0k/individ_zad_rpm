﻿using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;
using PathIO = System.IO.Path;
using PathShapes = System.Windows.Shapes.Path;


namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Торговля магазин;
    public MainWindow()
    {
        InitializeComponent();
        // Инициализация магазина с пустым списком
        магазин = new Торговля(new ObservableCollection<ОбъектПозиция>());
        this.DataContext = магазин; // Устанавливаем DataContext для привязки

    }

    private void BtnAddItem_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (ComboType.SelectedItem == null ||
                string.IsNullOrWhiteSpace(TxtRooms.Text) ||
                string.IsNullOrWhiteSpace(TxtArea.Text) ||
                string.IsNullOrWhiteSpace(TxtPrice.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            string типСтроения = (ComboType.SelectedItem as ComboBoxItem)?.Content.ToString();
            int количествоКомнат = int.Parse(TxtRooms.Text);
            int метраж = int.Parse(TxtArea.Text);
            int стоимость = int.Parse(TxtPrice.Text);

            Объекты новыйОбъект = new Объекты
            {
                ТипСтроения = типСтроения,
                КоличествоКомнат = количествоКомнат,
                Метраж = метраж,
                Стоимость = стоимость
            };

            ОбъектПозиция новыйТовар = new ОбъектПозиция(новыйОбъект);
            магазин.СписокТоваров.Add(новыйТовар);

            // Очистить поля
            ComboType.SelectedIndex = 0;
            TxtRooms.Clear();
            TxtArea.Clear();
            TxtPrice.Clear();

            MessageBox.Show("Товар добавлен.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при добавлении товара: " + ex.Message);
        }
    }
    private void OpenJsonFile(string filePath)
    {
        try
        {
            string json = File.ReadAllText(filePath, Encoding.UTF8);

            // Попробуем сначала разобрать как массив объектов
            if (json.TrimStart().StartsWith("["))
            {
                var объекты = JsonSerializer.Deserialize<List<Объекты>>(json);

                if (объекты == null || объекты.Count == 0)
                {
                    MessageBox.Show("Файл пуст или не содержит объектов.");
                    return;
                }

                foreach (var объект in объекты)
                {
                    ОбъектПозиция товар = new ОбъектПозиция(объект);
                    магазин.СписокТоваров.Add(товар);
                }

                MessageBox.Show($"Загружено {объекты.Count} объектов из массива JSON.");
            }
            else
            {
                var obj = JsonSerializer.Deserialize<Объекты>(json);

                if (obj == null)
                {
                    MessageBox.Show("Файл пуст или содержит некорректные данные.");
                    return;
                }

                ОбъектПозиция товар = new ОбъектПозиция(obj);
                магазин.СписокТоваров.Add(товар);

                MessageBox.Show("Загружен один объект из JSON файла.");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при чтении JSON файла: " + ex.Message);
        }
    }

    private void OpenTxtFile(string filePath)
    {
        try
        {
            string[] lines = File.ReadAllLines(filePath, Encoding.UTF8);

            if (lines.Length == 0)
            {
                MessageBox.Show("Файл пуст.");
                return;
            }

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue; // пропускаем пустые строки

                string[] parts = line.Split('*');

                if (parts.Length != 4)
                {
                    MessageBox.Show($"Ошибка в строке: {line}\nОжидалось 4 значения, разделенные '*'.");
                    continue;
                }

                string типСтроения = parts[0];
                int количествоКомнат = int.Parse(parts[1]);
                int метраж = int.Parse(parts[2]);
                int стоимость = int.Parse(parts[3]);

                // Создаём новый объект
                Объекты объект = new Объекты
                {
                    ТипСтроения = типСтроения,
                    КоличествоКомнат = количествоКомнат,
                    Метраж = метраж,
                    Стоимость = стоимость
                };

                // Оборачиваем в ОбъектПозиция и добавляем в список
                магазин.СписокТоваров.Add(new ОбъектПозиция(объект));
            }

            MessageBox.Show("Данные из текстового файла успешно добавлены.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при чтении TXT файла: " + ex.Message);
        }
    }




    // Открытие файла (реализовано ранее)

    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "JSON файлы (*.json)|*.json|Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*"
        };

        if (openFileDialog.ShowDialog() == true)
        {
            string filePath = openFileDialog.FileName;

            // Определяем расширение файла

            string fileExtension = PathIO.GetExtension(filePath); // Использование Path из System.IO


            if (fileExtension == ".json")
            {
                // Обрабатываем JSON файл
                OpenJsonFile(filePath);
            }
            else if (fileExtension == ".txt")
            {
                // Обрабатываем TXT файл
                OpenTxtFile(filePath);
            }
            else
            {
                MessageBox.Show("Неизвестный формат файла.");
            }

        }
    }
    private void BtnCreateFile_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "Текстовые файлы (*.txt)|*.txt|JSON файлы (*.json)|*.json|Все файлы (*.*)|*.*",
                Title = "Сохранить данные"
            };

            if (saveDialog.ShowDialog() == true)
            {
                string filePath = saveDialog.FileName;
                string fileExtension = PathIO.GetExtension(filePath);

                // Собираем данные из MainList
                var объектыИзСписка = new List<Объекты>();

                foreach (var item in MainList.Items)
                {
                    if (item is ОбъектПозиция позиция)
                    {
                        var объект = new Объекты
                        {
                            ТипСтроения = позиция.ТипСтроения,
                            КоличествоКомнат = позиция.КоличествоКомнат,
                            Метраж = позиция.Метраж,
                            Стоимость = позиция.Стоимость
                        };
                        объектыИзСписка.Add(объект);
                    }
                }

                if (fileExtension == ".txt")
                {
                    // Формируем строку для записи
                    StringBuilder sb = new StringBuilder();
                    foreach (var объект in объектыИзСписка)
                    {
                        sb.AppendLine($"{объект.ТипСтроения}*{объект.КоличествоКомнат}*{объект.Метраж}*{объект.Стоимость}");
                    }

                    File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8);
                }
                else if (fileExtension == ".json")
                {
                    var options = new JsonSerializerOptions { WriteIndented = true };
                    string newJson = JsonSerializer.Serialize(объектыИзСписка, options);
                    File.WriteAllText(filePath, newJson, Encoding.UTF8);
                }

                MessageBox.Show("Файл успешно сохранён.");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при сохранении файла: " + ex.Message);
        }
    }

    private void BtnDeleteItem_Click(object sender, RoutedEventArgs e)
    {
        var selectedItem = MainList.SelectedItem as ОбъектПозиция;

        if (selectedItem == null)
        {
            MessageBox.Show("Сначала выберите элемент для удаления.");
            return;
        }

        var result = MessageBox.Show("Вы действительно хотите удалить выбранный элемент?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);

        if (result == MessageBoxResult.Yes)
        {
            магазин.СписокТоваров.Remove(selectedItem);
            MessageBox.Show("Элемент удалён.");

            if (!string.IsNullOrWhiteSpace(текущийФайлПуть))
            {
                try
                {
                    // Перезаписываем файл с обновлённым списком
                    var строки = магазин.СписокТоваров.Select(item =>
                        $"{item.ТипСтроения}*{item.КоличествоКомнат}*{item.Метраж}*{item.Стоимость}");

                    File.WriteAllLines(текущийФайлПуть, строки, Encoding.UTF8);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при обновлении файла: " + ex.Message);
                }
            }
        }
    }
    private string текущийФайлПуть = null;

    private void BtnLoadJson_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            // Собираем данные из полей
            string типСтроения = (ComboType.SelectedItem as ComboBoxItem)?.Content.ToString();
            int количествоКомнат = int.Parse(TxtRooms.Text);
            int метраж = int.Parse(TxtArea.Text);
            int стоимость = int.Parse(TxtPrice.Text);

            // Создаем объект на основе введённых данных
            var объект = new Объекты
            {
                ТипСтроения = типСтроения,
                КоличествоКомнат = количествоКомнат,
                Метраж = метраж,
                Стоимость = стоимость
            };

            // Сериализуем объект в JSON с нужной кодировкой
            var options = new JsonSerializerOptions
            {
                WriteIndented = true,  // Сделать отступы для читабельности
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping // Позволяет избежать Unicode escape
            };

            string json = JsonSerializer.Serialize(объект, options);

            // Открываем диалог для сохранения файла
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "JSON файлы (*.json)|*.json|Все файлы (*.*)|*.*",
                FileName = "данные.json"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                // Записываем JSON в выбранный файл
                File.WriteAllText(saveFileDialog.FileName, json, Encoding.UTF8);
                MessageBox.Show("JSON файл успешно создан и сохранён.");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при создании JSON файла: " + ex.Message);
        }
    }
    private void GetValuesFromJsonByKey(string filePath, string key)
    {
        try
        {
            string json = File.ReadAllText(filePath, Encoding.UTF8);

            using JsonDocument doc = JsonDocument.Parse(json);

            List<string> найденныеЗначения = new List<string>();

            if (doc.RootElement.ValueKind == JsonValueKind.Array)
            {
                // Если массив — проходим по всем элементам
                foreach (var элемент in doc.RootElement.EnumerateArray())
                {
                    if (элемент.TryGetProperty(key, out JsonElement value))
                    {
                        найденныеЗначения.Add(value.ToString());
                    }
                }
            }
            else if (doc.RootElement.ValueKind == JsonValueKind.Object)
            {
                // Если это один объект — ищем сразу в нём
                if (doc.RootElement.TryGetProperty(key, out JsonElement value))
                {
                    найденныеЗначения.Add(value.ToString());
                }
            }
            else
            {
                MessageBox.Show("Файл не содержит ни объект, ни массив объектов.");
                return;
            }

            if (найденныеЗначения.Count > 0)
            {
                // Показываем все найденные значения
                string result = string.Join(Environment.NewLine, найденныеЗначения);
                MessageBox.Show($"Найденные значения по ключу \"{key}\":\n{result}");

                // Можно автоматически подставить первое значение в форму
                string первоеЗначение = найденныеЗначения[0];
                ПодставитьЗначениеВФорму(key, первоеЗначение);
            }
            else
            {
                MessageBox.Show($"Ключ \"{key}\" не найден.");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при поиске ключа в JSON: " + ex.Message);
        }
    }


    private void ПодставитьЗначениеВФорму(string key, string value)
    {
        switch (key)
        {
            case "ТипСтроения":
                foreach (ComboBoxItem item in ComboType.Items)
                {
                    if (item.Content.ToString() == value)
                    {
                        ComboType.SelectedItem = item;
                        break;
                    }
                }
                break;

            case "КоличествоКомнат":
                TxtRooms.Text = value;
                break;

            case "Метраж":
                TxtArea.Text = value;
                break;

            case "Стоимость":
                TxtPrice.Text = value;
                break;

            default:
                MessageBox.Show("Неизвестный ключ. Данные не были подставлены в форму.");
                break;
        }
    }
    private void BtnGetJsonKey_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "JSON файлы (*.json)|*.json"
        };

        if (openFileDialog.ShowDialog() == true)
        {
            string filePath = openFileDialog.FileName;

            string key = Microsoft.VisualBasic.Interaction.InputBox(
                "Введите ключ для поиска в JSON:",
                "Поиск ключа",
                "ТипСтроения"
            );

            if (!string.IsNullOrWhiteSpace(key))
            {
                // Теперь вызываем обновлённый метод
                GetValuesFromJsonByKey(filePath, key);
            }
        }
    }



}




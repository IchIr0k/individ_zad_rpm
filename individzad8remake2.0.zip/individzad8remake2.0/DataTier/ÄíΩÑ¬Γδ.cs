﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTier
{
    public class Объекты
    {
        public string ТипСтроения { get; set; }
        public int КоличествоКомнат { get; set; }
        public int Метраж { get; set; }
        public int Стоимость { get; set; }
    }
}

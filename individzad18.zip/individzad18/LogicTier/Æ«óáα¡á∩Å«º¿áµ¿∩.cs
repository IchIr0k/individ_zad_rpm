﻿
using DataTier;

namespace LogicTier
{
    public class ТоварнаяПозиация
    {
        private Товар _товар;

        public ТоварнаяПозиация(Товар p)
        {
            _товар = p;
        }
        public string ТипСтроения
        {
            get { return _товар.ТипСтроения; }
            set { _товар.ТипСтроения = value; }
        }
        public int КоличествоКомнат
        {
            get { return _товар.КоличествоКомнат; }
            set { _товар.КоличествоКомнат = value; }
        }
        public float Метраж
        {
            get { return _товар.Метраж; }
            set { _товар.Метраж = value; }
        }
        public float Стоимость
        {
            get { return _товар.Стоимость; }
            set { _товар.Стоимость = value; }
        }
        public float СуммарнаяСтоимостьПозиции
        {
            get { return _товар.Стоимость; }
        }
        public string ПредставлениеТовара
        {
            get
            {
                return _товар.ТипСтроения + " : " + _товар.КоличествоКомнат
                    + " - " + _товар.Метраж+"м. - "+_товар.Стоимость+"руб.";
            }
        }

    }
}

﻿namespace DataTier
{
    public class Товар
    {
        public String ТипСтроения {  get; set; }
        public int КоличествоКомнат { get; set; }
        public float Метраж { get; set; }
        public float Стоимость { get; set; }
        public string ПредставлениеТовара => $"{ТипСтроения} - {КоличествоКомнат} - {Метраж} - {Стоимость}₽)";
    }

}

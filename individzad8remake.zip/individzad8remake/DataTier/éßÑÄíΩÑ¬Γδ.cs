﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTier
{
    public class ВсеОбъекты
    {
        public static void СохранитьВсеТовары(List<Объекты> товары)
        {

        }
        public static List<Объекты> ПолучитьВсеТоварыИзФайла(string путь)
        {
            var список = new List<Объекты>();

            if (!File.Exists(путь))
                return список;

            var строки = File.ReadAllLines(путь);

            foreach (var строка in строки)
            {
                if (string.IsNullOrWhiteSpace(строка)) continue;

                var части = строка.Split('*');
                if (части.Length != 4) continue;

                try
                {
                    string типСтроения = части[0];
                    int количествоКомнат = int.Parse(части[1]);
                    int метраж = int.Parse(части[2]);
                    int стоимость = int.Parse(части[3]);

                    список.Add(new Объекты
                    {
                        ТипСтроения = типСтроения,
                        КоличествоКомнат = количествоКомнат,
                        Метраж = метраж,
                        Стоимость = стоимость
                    });
                }
                catch
                {
                    // Можно логировать ошибку
                }
            }

            return список;
        }


    }
}

﻿namespace DataTier
{
    public class Товар
    {
        public string ТипСтроения {  get; set; }
        public int КоличествоКомнат { get; set; }
        public int Метраж { get; set; }
        public int Стоимость { get; set; }
        public string ПредставлениеТовара => $"{ТипСтроения} - {КоличествоКомнат} - {Метраж} - {Стоимость}₽)";
    }

}

﻿using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Торговля магазин;
    public MainWindow()
    {
        InitializeComponent();
        // Инициализация магазина с пустым списком
        магазин = new Торговля(new ObservableCollection<ОбъектПозиция>());
        this.DataContext = магазин; // Устанавливаем DataContext для привязки

    }
    private void BtnAddItem_Click(object sender, RoutedEventArgs e)
    {
        string line = TxtAdd.Text.Trim(); // Удаляем лишние пробелы

        if (string.IsNullOrWhiteSpace(line))
        {
            MessageBox.Show("Введите текст для добавления.");
            return;
        }

        string[] parts = line.Split('*');

        if (parts.Length != 4)
        {
            MessageBox.Show("Неверный формат строки. Должно быть 4 значения, разделенные '*'.");

            return;
        }

        try
        {
            string типСтроения = parts[0];
            int количествоКомнат = int.Parse(parts[1]);
            int метраж = int.Parse(parts[2]);
            int стоимость = int.Parse(parts[3]);

            Объекты новыйОбъект = new Объекты
            {
                ТипСтроения = типСтроения,
                КоличествоКомнат = количествоКомнат,
                Метраж = метраж,
                Стоимость = стоимость
            };

            // Создаем объект позиции и добавляем в коллекцию
            ОбъектПозиция новыйТовар = new ОбъектПозиция(новыйОбъект);
            магазин.СписокТоваров.Add(новыйТовар);

            TxtAdd.Clear(); // Очистить поле ввода
            MessageBox.Show("Товар добавлен.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при обработке данных: " + ex.Message);
        }
    }

    // Открытие файла (реализовано ранее)
    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*"
        };

        if (openFileDialog.ShowDialog() == true)
        {
            текущийФайлПуть = openFileDialog.FileName;

            List<Объекты> товарыИзФайла = ВсеОбъекты.ПолучитьВсеТоварыИзФайла(текущийФайлПуть);

            if (товарыИзФайла.Count == 0)
            {
                MessageBox.Show("Нет товаров в файле!");
                return;
            }

            ObservableCollection<ОбъектПозиция> позиции = new ObservableCollection<ОбъектПозиция>();
            foreach (var t in товарыИзФайла)
            {
                позиции.Add(new ОбъектПозиция(t));
            }

            магазин = new Торговля(позиции);
            this.DataContext = магазин;
        }
    }

    private void BtnCreateFile_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in магазин.СписокТоваров)
            {
                sb.AppendLine($"{item.ТипСтроения}*{item.КоличествоКомнат}*{item.Метраж}*{item.Стоимость}");
            }

            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*",
                Title = "Сохранить данные"
            };

            if (saveDialog.ShowDialog() == true)
            {
                File.WriteAllText(saveDialog.FileName, sb.ToString(), Encoding.UTF8);
                MessageBox.Show("Файл успешно сохранён.");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при сохранении файла.");
        }
    }

    private void BtnDeleteItem_Click(object sender, RoutedEventArgs e)
    {
        var selectedItem = MainList.SelectedItem as ОбъектПозиция;

        if (selectedItem == null)
        {
            MessageBox.Show("Сначала выберите элемент для удаления.");
            return;
        }

        var result = MessageBox.Show("Вы действительно хотите удалить выбранный элемент?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);

        if (result == MessageBoxResult.Yes)
        {
            магазин.СписокТоваров.Remove(selectedItem);
            MessageBox.Show("Элемент удалён.");

            if (!string.IsNullOrWhiteSpace(текущийФайлПуть))
            {
                try
                {
                    // Перезаписываем файл с обновлённым списком
                    var строки = магазин.СписокТоваров.Select(item =>
                        $"{item.ТипСтроения}*{item.КоличествоКомнат}*{item.Метраж}*{item.Стоимость}");

                    File.WriteAllLines(текущийФайлПуть, строки, Encoding.UTF8);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при обновлении файла: " + ex.Message);
                }
            }
        }
    }
    private string текущийФайлПуть = null;

}




﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataTier;

namespace LogicTier
{
    public class ОбъектПозиция
    {
        private Объекты _товар;

        public ОбъектПозиция(Объекты p)
        {
            _товар = p;
        }
        public string ТипСтроения
        {
            get { return _товар.ТипСтроения; }
            set { _товар.ТипСтроения = value; }
        }
        public int КоличествоКомнат
        {
            get { return _товар.КоличествоКомнат; }
            set { _товар.КоличествоКомнат = value; }
        }
        public int Метраж
        {
            get { return _товар.Метраж; }
            set { _товар.Метраж = value; }
        }
        public int Стоимость
        {
            get { return _товар.Стоимость; }
            set { _товар.Стоимость = value; }
        }
        public string ПредставлениеТовара
        {
            get
            {
                return $"{ТипСтроения}, {КоличествоКомнат} комнат., {Метраж} м², {Стоимость} руб.";
            }
        }
    }
}

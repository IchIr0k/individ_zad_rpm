﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace LogicTier
{
    public class Торговля : INotifyPropertyChanged
    {
        private ObservableCollection<ОбъектПозиция> _товары;

        public Торговля(ObservableCollection<ОбъектПозиция> позиции)
        {
            _товары = позиции;
            _товары.CollectionChanged += (s, e) =>
            {
                OnPropertyChanged(nameof(СуммарнаяСтоимостьПоТипу));
                OnPropertyChanged(nameof(СредняяСтоимостьКвМетра));
            };
        }

        public ObservableCollection<ОбъектПозиция> СписокТоваров
        {
            get => _товары;
        }

        public string СуммарнаяСтоимостьПоТипу
        {
            get
            {
                var grouped = _товары
                    .GroupBy(p => p.ТипСтроения)
                    .Select(g => new
                    {
                        Тип = g.Key,
                        Сумма = g.Sum(p => p.Стоимость)
                    });

                return string.Join(System.Environment.NewLine, grouped.Select(g => $"{g.Тип}: {g.Сумма}"));
            }
        }

        public string СредняяСтоимостьКвМетра
        {
            get
            {
                var стоимости = _товары
                    .Where(p => p.Метраж > 0)
                    .Select(p => (double)p.Стоимость / p.Метраж);

                return стоимости.Any()
                    ? $"{стоимости.Average():F2}"
                    : "Нет данных";
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
